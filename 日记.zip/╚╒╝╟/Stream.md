## Stream

Java 8 新特性

可以支持顺序和并行的对原Stream进行汇聚的操作

使用Stream的基本步骤

1. 创建Stream；
2. 转换Stream，每次转换原有Stream对象不改变，返回一个新的Stream对象（**可以有多次转换**）；
3. 对Stream进行聚合（Reduce）操作，获取想要的结果；

#### 创建 Stream

1. 通过Stream接口的静态工厂方法（注意：Java8里接口可以带静态方法）；
2. 通过Collection接口的默认方法，把一个 Collection 对象转换成 Stream

##### 使用Stream静态方法来创建Stream

of方法：有两个overload方法，一个接受变长参数，一个接口单一值

```java
Stream<Integer> integerStream = Stream.of(1,2,3,5);
Stream<String> stringStream = Stream.of("taobao");
```

generator方法：生成一个无限长度的Stream，其元素的生成是通过给定的Supplier（这个接口可以看成一个对象的工厂，每次调用返回一个给定类型的对象）

```java
Stream.generate(new Supplier<Double>() {
	@Override
	public Double get() {
		return Math.random();
	}
});

Stream.generate(()-> Math.random());
Stream.generate(Math::random);
```

iterate方法：也是生成无限长度的Stream，和generator不同的是，其元素的生成是重复对给定的种子值(seed)调用用户指定函数来生成的。其中包含的元素可以认为是：seed，f(seed),f(f(seed))无限循环。

```java
Stream.iterate(1,item->item + 1).limit(10).forEach(System.out::println);
```

这段代码就是先获取一个无限长度的正整数集合的Stream，然后取出前10个打印。

通过Collection子类获取Stream。Collection接口有一个stream方法，所以其所有子类都都可以获取对应的Stream对象。

```java
Stream<E> stream();
```

#### 转换Stream

##### distinct

对于Stream中包含的元素进行去重操作（去重逻辑依赖元素的equals方法），新生成的Stream中没有重复的元素；

##### filter

对于Stream中包含的元素使用给定的过滤函数进行过滤操作，新生成的Stream只包含符合条件的元素；

##### map

对于Stream中包含的元素使用给定的转换函数进行转换操作，新生成的Stream只包含转换生成的元素。三个变种方法，分别是：mapToInt，mapToLong和mapToDouble。mapToInt就是把原始Stream转换成一个新的Stream，这个新生成的Stream中的元素都是int类型。这三个变种方法，可以免除自动装箱/拆箱的额外消耗。

##### flatMap

和map类似，不同的是其每个元素转换得到的是Stream对象，会把子Stream中的元素压缩到父集合中；

##### peek

生成一个包含原Stream的所有元素的新Stream，同时会提供一个消费函数（Consumer实例），新Stream每个元素被消费的时候都会执行给定的消费函数；

##### limit

对一个Stream进行截断操作，获取其前N个元素，如果原Stream中包含的元素个数小于N，那就获取其所有的元素；

##### skip

返回一个丢弃原Stream的前N个元素后剩下元素组成的新Stream，如果原Stream中包含的元素个数小于N，那么返回空Stream；

```java
List<Integer> nums = Lists.newArrayList(1,1,null,2,3,4,null,5,6,7,8,9,10);
System.out.println(“sum is:”+nums.stream().filter(num -> num != null).
                   distinct().mapToInt(num -> num *2).peek(System.out::println).skip(2).limit(4).sum());
```

#### 汇聚

接受一个元素序列为输入，反复使用某个合并操作，把序列中的元素合并成一个汇总的结果。比如查找一个数字列表的总和或者最大值，或者把这些数字累积成一个List对象。Stream接口有一些通用的汇聚操作，比如reduce()和collect()；也有一些特定用途的汇聚操作，比如sum(),max()和count()。注意：sum方法不是所有的Stream对象都有的，只有IntStream、LongStream和DoubleStream是实例才有。

##### 可变汇聚

把输入的元素们累积到一个可变的容器中，比如Collection或者StringBuilder

可变汇聚对应的只有一个方法：collect

##### 其他汇聚

除去可变汇聚剩下的，一般都不是通过反复修改某个可变对象，而是通过把前一次的汇聚结果当成下一次的入参，反复如此。比如reduce，count，allMatch；