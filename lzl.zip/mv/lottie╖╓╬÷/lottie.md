## Lottie

#### 支持的 After Effects 动画类型  

译者注：Lottie目前**不支持**的AE动效类型很多，例如常用的3D图层变换、几乎所有效果器[effects]、图层样式[layer styles]、叠加模式[blending mode]、渐变[gradient ramp/gradient fill...]（好像正在加入支持，期待更新）、任意表达式[expressions]、径向擦除[radius wipe]等。。。
在用AE制作动画的时候一定要看清楚能否拆解为以下支持的类型。

##### 预合成[Pre-composition]

------

##### 关键帧插值[Keyframe Interpolation]

------

- 线性插值[Linear Interpolation]
- 贝塞尔曲线插值[Bezier Interpolation]
- 定格插值[Hold Interpolation]
- 漂浮穿梭时间[Rove Across Time]
- 空间贝塞尔曲线[Spatial Bezier]

##### 固态层[Solids]

------

- 锚点变换[Transform Anchor Point]
- 位置变换[Transform Position]
- 缩放变换[Transform Scale]
- 旋转变换[Transform Rotation]
- 不透明度变换[Transform Opacity]

##### 蒙版[Masks]

------

- 蒙版路径[Path]
- 蒙版不透明度[Opacity]
- 多蒙版混合模式（相加、相减、反转）[Multiple Masks (additive, subtractive, inverted)]

##### 轨道遮罩[Track Mattes]

------

- Alpha 遮罩[Alpha Matte]

##### 父级[Parenting]

------

- 多个父级[Multiple Parenting]
- 空对象[Nulls]

##### 形状图层[Shape Layers]

------

- 矩形（所有属性）[Rectangle (All properties)]
- 椭圆（所有属性）[Ellipse (All properties)]
- 多边星形（所有属性）[Polystar (All properties)]
- 多边形（所有属性。点个数必须为整数。）[Polygon (All properties. Integer point values only.)]
- 路径变换（所有属性）[Path (All properties)]
- 锚点变换[Anchor Point]
- 位置变换[Position]
- 缩放变换[Scale]
- 旋转变换[Rotation]
- 不透明度[Opacity]
- 形状组变换（锚点、位置、缩放……）[Group Transforms (Anchor point, position, scale etc)]
- 一个形状组可包含多个形状 [Multiple paths in one group]
- 合并路径（默认是关闭的，必须用enableMergePathsForKitKatAndAbove方法专门开启）[Merge paths (off by default and must be explicitly enabled with enableMergePathsForKitKatAndAbove)]

##### 形状图层描边 [Stroke (shape layer)]

------

- 描边颜色[Stroke Color]
- 描边不透明度[Stroke Opacity]
- 描边宽度[Stroke Width]
- 描边端点[Line Cap]
- 虚线[Dashes]

##### 形状图层填充[Fill (shape layer)]

------

- 填充颜色[Fill Color]
- 填充不透明度[Fill Opacity]

##### 修剪路径[Trim Paths (shape layer)]

------

- 修剪路径开始[Trim Paths Start]
- 修剪路径结束[Trim Paths End]
- 修剪路径偏移[Trim Paths Offset]

#### 性能和内存占用

1. 如果动画合成中没有遮罩或者蒙版，性能和内存开销会非常棒。此时没有位图生成，大部分操作都是简单的canvas画布操作。
2. 如果合成中存在遮罩或者蒙版, 动画将会使用脱屏缓冲区（offscreen buffer），性能将会受到影响。
3. 如果你在一个列表中使用动画, 我们建议你配置 LottieAnimationView.setAnimation(String, CacheStrategy) 的第二个参数——缓存策略，这样动画就不必每次都反序列化。